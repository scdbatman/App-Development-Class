//
//  Login_labTests.swift
//  Login labTests
//
//  Created by Samuel Bradshaw  on 1/29/25.
//

import Testing
@testable import Login_lab

struct Login_labTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
