//  🏔️ MTECH Code Challenge GC26: "Final Challenge Jam"
//  Concept: Code creatively!

//  Instructions:
    //  You have 25 minutes to write any program you want. At the end of 25 minutes, all students will share their code and the class will vote on who wrote the best program in the time allotted. Winner gets a prize!

//  Notes:
    //  For larger classes, instead of each of us sharing, all students will share with a small group, then each group will nominate one student to be a finalist, then all students will vote on a winner.

//  Tips:
    //  If you want to include a user interface, you can find the boilerplate code required to run SwiftUI Previews in Playground in code challenge ST10, or you may create a full project and replace this playground.

import Foundation

