//  🏔️ MTECH Code Challenge ST20: "Special Topics Unit Review"
//  Concept: Review the topics discussed this course

//  Instructions:
    //  Answer the questions below. Provide code samples if relevant to your answer. You have 15 minutes to answer, after which we will have 10 minutes to discuss; give brief answers and work quickly to ensure you answer all questions.

import Foundation

//  Question 1: What are the major differences, advantages and disadvantages of SwiftUI over UIKit?



//  Question 2: Give a brief overview of process of using Test Driven Development. What are the steps? What are its philosophies?



//  Question 3: What is CoreData? What is the process of setting it up and using it?



//  ⛋ Black Diamond Question: What is SwiftData? How does it relate to CoreData? What are its advantages and disadvantages?



