//
//  ListTableViewController.swift
//  User Notification Practice
//
//  Created by Brad Forsyth on 4/15/25.
//

import UIKit

class ListTableViewController: UITableViewController {
    
    var journalEntries: [JournalEntry] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = "Journal"
    }
    
    // MARK: - UITableView
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        journalEntries.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "JournalEntryCell", for: indexPath)
        
        let entry = journalEntries[indexPath.row]
        cell.textLabel?.text = entry.dateString
        cell.detailTextLabel?.text = entry.text
        
        return cell
    }
    
    // MARK: - Segue
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "entrySegue" {
            if let indexPath = tableView.indexPathForSelectedRow {
                let entry = journalEntries[indexPath.row]
                let destinationNavController = segue.destination as! UINavigationController
                let destinationViewController = destinationNavController.viewControllers.first as! EntryViewController
                destinationViewController.delegate = self
                destinationViewController.journalEntry = entry
            }
        } else if segue.identifier == "newEntrySegue" {
            let destinationNavController = segue.destination as! UINavigationController
            let destinationViewController = destinationNavController.viewControllers.first as! EntryViewController
            destinationViewController.delegate = self
        }
    }
}

extension ListTableViewController: EntryViewDelegate {
    func journalEntryDidSave(_ journalEntry: JournalEntry) {
        if let existingEntry = self.journalEntries.first(where: { $0.identifer == journalEntry.identifer }) {
            existingEntry.text = journalEntry.text
        } else {
            self.journalEntries.append(journalEntry)
            self.journalEntries.sort { $0.date > $1.date }
        }
        self.tableView.reloadData()
    }
}
