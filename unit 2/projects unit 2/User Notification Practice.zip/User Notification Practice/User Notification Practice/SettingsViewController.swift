//
//  SettingsViewController.swift
//  User Notification Practice
//
//  Created by Brad Forsyth on 4/21/25.
//

import UIKit

class SettingsViewController: UIViewController {
    
    @IBOutlet var reminderToggle: UISwitch!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = "Settings"
        
        reminderToggle.isOn = UserDefaults.standard.bool(forKey: "reminderEnabled")
    }
    
    @IBAction func doneButtonTapped(_ sender: Any) {
        self.dismiss(animated: true)
    }
    
    @IBAction func reminderToggleValueChanged(_ sender: UISwitch) {
        
        
        UserDefaults.standard.set(reminderToggle.isOn, forKey: "reminderEnabled")
    }
    
}
